#ifndef CANSAT_FILE_NAMES_H
#define CANSAT_FILE_NAMES_H

#define reference_values_file_name "ref.csv"
#define last_state_file_name "ls.csv"
#define test_file "reftest.csv"
#define logger_file_name "log.csv"

#endif /* CANSAT_FILE_NAMES_H */
